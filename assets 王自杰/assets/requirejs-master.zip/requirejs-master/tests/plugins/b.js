define(function () {
    return {
        name: "b"
    };
});
