define(['collection', 'text!specificCollection.html'], function (collection, html) {
    return {
        name: 'specificCollection',
        html: html,
        collection: collection
    };
});