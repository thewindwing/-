define({
    name: 'bar',
    version: '0.4'
});
