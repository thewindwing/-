define(function () {
    return 'beta';
});
