doh.is("complete", document.readyState);
d.callback(true);
