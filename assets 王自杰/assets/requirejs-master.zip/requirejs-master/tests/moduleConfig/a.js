define(['module'], function (module) {
    return {
        type: module.config().id
    };
});
