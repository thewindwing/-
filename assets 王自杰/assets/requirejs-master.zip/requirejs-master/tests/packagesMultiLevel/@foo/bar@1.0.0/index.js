define(['./other'], function (other) {
    return {
        name: 'bar',
        other: other
    };
});
