$.fn.beta = function() {
    return "beta";
};
