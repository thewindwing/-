define("foo/three", {
    name: "three"
});
