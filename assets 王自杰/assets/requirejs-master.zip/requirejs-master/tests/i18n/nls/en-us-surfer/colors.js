define({
    red: "red, dude",
    black: {
        opacity: 0.5
    }
});
