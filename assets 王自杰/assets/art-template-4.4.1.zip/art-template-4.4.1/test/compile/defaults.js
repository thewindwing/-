const assert = require('assert');
const defaults = require('../../src/compile/defaults');
module.exports = {

    before: () => {
        console.log('#compile/defaults');
    }
};