## LESScss source files

Files in this folder are used to compile the Jcrop.css file from .less definitions.

##### Compiling with Grunt

    $ npm install
    $ grunt css
