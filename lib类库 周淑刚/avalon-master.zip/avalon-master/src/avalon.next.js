var avalon = require('./seed/modern') 

require('./filters/index')
require('./vdom/index')
require('./dom/modern')
require('./directives/modern')
require('./strategy/index')
require('./component/index')
require('./vmodel/next')


module.exports = avalon
