
/*********************************************************************
 *                          DOM Api                                 *
 *           shim,class,data,css,val,html,event,ready               *
 **********************************************************************/

require('./shim/modern')
require('./class/modern')
require('./data/modern')
require('./css/modern')
require('./val/modern')
require('./html/modern')
require('./event/modern')
require('./ready/modern')

module.exports = avalon
